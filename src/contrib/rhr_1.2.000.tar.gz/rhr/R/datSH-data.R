##' @name datSH
##' @title Tracking data of one red deer in Germany
##' @description data set from one red deer from northern Germany
##' @docType data
##' @usage datSH
##' @format 1 location per row
##' @source Verein fuer Wildtierforschung Goettingen and Dresden
##' @author Johannes Signer, 2012-03-05
NULL
