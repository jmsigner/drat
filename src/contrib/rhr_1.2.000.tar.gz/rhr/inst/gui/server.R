
## For the packaged version: make an optinal data argument and
## outputDir argument. They will be set static and be identical for each client.
## This shouldn't be a problem, if the app is run locally

## clean everything 
rm(list=ls())
debug <- FALSE
if (debug) {
  .datFromR <- NULL
  outDir <- "/tmp"
}

## Max upload size
options(shiny.maxRequestSize=30*1024^2)
#####

library(brew)
library(lubridate)
library(knitr)
library(markdown)
library(rgdal)
library(rhr)
library(shinyBS)
library(shiny)
library(xtable)

shinyServer(function(input, output, session) {
  ## ============================================================================== ##  
  ## Set up


  ##  runId <- paste0("rhr-run-", format(now(), "%Y%m%d%H%M%S"))
  ##  outDir <- normalizePath(file.path(normalizePath(tempdir(), winslash="/"), runId), winslash="/")
  ##  dir.create(outDir)
  ##  addResourcePath("out", outDir)


  if (debug) cat("====================================================\n", file=stderr())
  if (debug) cat(outDir, "\n", file=stderr())


  ## ============================================================================== ##  
  ## Read data

  data <- reactive({

    if (is.null(.datFromR)) {

      res <- paste0('Unable to load data, did you select a file?')
      dat <- NULL
      exitStatus <- 1


      if (!is.null(input$readFileFile)) {
        sep <- switch(input$readFileFieldSep,
                      comma=",",
                      tab="\t",
                      semi=";")

        ## asign decimal separator
        sepDec <- switch(input$readFileSepDec,
                         comma=",",
                         point=".")

        dat <- tryCatch(rhrReadData(input$readFileFile$datapath,
                                    sep=sep,
                                    skip=input$readFileSkipLines,
                                    hasHeader=input$readFileHasHeader),
                        error=function(e) e)

        if (!is(dat, "error")) {
          res <- "Data successfully read"
          exitStatus <- 0
        } else {
          res <- paste0("Something went wrong:", dat$message)
          exitStatus <- 1
        }
      } 
      list(data=dat, message=res, exitStatus=exitStatus)
    } else {
      list(data=.datFromR, message="Data read from R", exitStatus=0)
    }
  })

  observe({
    createAlert(session, "alertLoadData", "a1",
                "Reading Input Data",
                content=data()$message,
                style=if(data()$exitStatus == 1) "error" else "success",
                dismiss=TRUE,
                append=FALSE)
  })

  output$readFileTable <- renderUI({
    if (!is.null(data()$data)) {
      list(
        h2("Preview of data"),
        p("The frist 25 relocations the data are shown below"), 
        renderTable(head(data()$data, 25))
      )
    } else {
      list(
        h2("No data loaded yet"),
        helpText("Please upload data first, using the panel on the left hand side")
      )
    }
  })


  ## We can only proceed if this is true
  succesfullyFinishedS1 <- reactive({
    if (debug) cat("\n Entered successfullyFinishedS1 \n")
    if (debug) cat(str(data()$data))
    if (!is.null(data()$data) & data()$exitStatus == 0) {
      TRUE
    } else {
      FALSE
    }
  })
  
  ## All Settings
  config <- reactive({
    list(
      general=list(
        name="General Settings",
        content=list(
          doPdf=input$configOutputMkPdf,
          doCp=input$configOutputCpWd,
          wd=normalizePath(.outDir, mustWork=FALSE, winslash="/"), 
          ## doZip=input$configOutputZip,
          ## zipPath=normalizePath(file.path(outDir, paste0(runId, ".zip")), winslash="/"),
          fileName=if (!is.null(input$readFileFile$name)) input$readFileFile$name else "data read from R", 
          ## fileSize=input$readFileFile$size,
          fieldSeparator=input$readFileFieldSep,
          decSeparator=input$readFileSepDec,
          hasHeader=input$readFileHasHeader,
          skip=input$readFileSkipLines
        )), 
      fields=list(
        name="Remapping of Fields",
        content=list(
          id=input$mfId, 
          lon=input$mfX, 
          lat=input$mfY, 
          date=input$mfDate, 
          time=input$mfTime, 
          dateFormat=input$mfDateFormat, 
          timeFormat=input$mfTimeFormat)
      )
    )
  })

  ## ============================================================================= ##
  ## Remap fields

  observe({
    if (!succesfullyFinishedS1()) {
      createAlert(session, "alertMapFields", "remapFieldsA1",
                  "Mapping Fields",
                  content = "Data must be read before remapping", 
                  style="info", 
                  dismiss=FALSE,
                  append=FALSE)
    } else {
      closeAlert(session, "remapFieldsA1")

      ## update map fields selectors
      mfChoices <- c(NA, names(data()$data))
      updateSelectInput(session, "mfId", choices = mfChoices)
      updateSelectInput(session, "mfX", choices = mfChoices)
      updateSelectInput(session, "mfY", choices = mfChoices)
      updateSelectInput(session, "mfDate", choices = mfChoices)
      updateSelectInput(session, "mfTime", choices = mfChoices)
      updateSelectInput(session, "mfDateFormat",
                        choices = c("ymd", "dmy", "mdy", "ymd_h", "ymd_hm",
                          "ymd_hms", "dmy_h", "dmy_hm", "dmy_hms", "mdy_h",
                          "mdy_hm", "mdy_hms"))
      updateSelectInput(session, "mfTimeFormat", choices = c("hm", "hms"))

      if (debug) cat("\n Updated Select Input \n")
    }
  })

  ## ------------------------------------------------------------------------------ ##  
  ## check for EPSG codes


  output$reproject <- renderUI({
    if (rhrValidEpsg(input$configInEpsg)) {
      return(list(
        helpText(paste0("Optionally you can reproject your data (Input EPSG is: ",
                        input$configInEpsg, ")")), 
        numericInput("configOutEpsg", "Output EPSG", NA), 
        textOutput("rhrReproject")))
    } else {
      return(list(
        helpText("Invalid or no input EPSG provided")
      ))
    }
  })

  ##
  ## Remapping of the fields happens here

  data2 <- reactive({
    if (debug) cat("\n Entered data2 \n\n")
    if (succesfullyFinishedS1()) {
      id         <- ifelse(input$mfId == "NA", NA, input$mfId)
      lon        <- ifelse(input$mfX == "NA", NA, input$mfX)
      lat        <- ifelse(input$mfY == "NA", NA, input$mfY)
      date       <- ifelse(input$mfDate == "NA", NA, input$mfDate)
      time       <- ifelse(input$mfTime == "NA", NA, input$mfTime)
      dateFormat       <- input$mfDateFormat
      timeFormat       <- input$mfTimeFormat

      if (debug) cat("lat : ", lat, "\n")
      if (debug) cat("lon : ", lon, "\n")

      if (!is.na(lon) & !is.na(lat)) {


        if (debug) cat("lat : ", (lat), "\n")
        if (debug) cat("lon : ", (lon), "\n")
        if (debug) cat("id class: ", class(id), "\n")

        if (debug) cat("Trying to remap", "\n")
        if (debug) cat(names(data()$data), "\n")
        if (debug) cat("Lookup ======= ", "\n")
        if (debug) cat(c(lon=lon, lat=lat, id=id, date=date, time=time), "\n")
        

        dat2 <- rhrMapFields(data()$data,
                             fields=list(lon=lon, lat=lat, id=id, date=date, time=time), 
                             projString=NULL, dateFormat=dateFormat,
                             timeFormat=timeFormat, defaultId="Animal1")


        if (debug) cat("\nstr(dat2)\n")
        if (debug) cat(str(dat2))
        if (debug) cat("\nclass(dat2)\n")
        if (debug) cat(class(dat2))
        if (debug) cat("\n===============\n")

        if (debug) cat(input$configInEpsg, "\n")
        if (debug) cat(input$configOutEpsg, "\n")

        ## Epsg can be used later
        if (!is.null(dat2)) {
          if (!is.null(input$configOutEpsg)) {
            if (!is.na(input$configOutEpsg)) {
              if (!is.na(input$configInEpsg)) {
                if (rhrValidEpsg(input$configOutEpsg)) {
                  ## should I also reproject
                  proj4string(dat2$dat) <- CRS(paste0("+init=epsg:", input$configInEpsg))
                  dat2$dat <- sp::spTransform(dat2$dat, CRS(paste0("+init=epsg:", input$configOutEpsg)))
                  createAlert(session, "rhrReproject", "rhrReproject1",
                              "Reproject",
                              content ="Data successfully reprojected", 
                              style="success", 
                              dismiss=TRUE,
                              append=FALSE)
                } else {
                  createAlert(session, "rhrReproject", "rhrReproject1",
                              "Reproject",
                              content = "Output EPSG not valid, won't reproject data", 
                              style="error", 
                              dismiss=TRUE,
                              append=FALSE)
                  
                }
              }
            }
          }
        }
        
        return(dat2)
      } else {
        return(NULL)
      }
    } else {
      if (debug) cat("dat2 is null\n")
      if (debug) cat("============ \n")
      return(NULL)
    }
  })

  missingAndDuplicated <- reactive({
    if (!is.null(data())) {
      ff <- data.frame(
        id=names(unlist(data2()$res$nobs)),
        nobs=unlist(data2()$res$nobs), 
        missing=unlist(data2()$res$nIncompleteCases),
        nDuplicated=unlist(data2()$res$nDuplicated),
        finalN=data2()$res$nobsFinal)
      names(ff) <- c("Id", "Number observations", "Number missing", "Number Duplicated", "Final number")
      ff
    }
  })

  output$mfUI <- renderUI({
    if (!is.null(data2())) {
      if (debug) cat("str mfUI ---------- \n")
      if (debug) cat(str(data2()),  "\n")
      ## ugly workaround to get date displayed properly
      dat2Temp <- head(as.data.frame(data2()$dat), 25)
      dat2Temp$timestamp <- as.character(dat2Temp$timestamp)

      
      list(
        h2("Missing and duplicated cases"),
        renderDataTable(missingAndDuplicated()), 
        h2("Preview of data"),
        p("The frist 25 relocations the data are shown below"), 
        renderTable(dat2Temp)
      )
    } else {
      list(
        h2("Data not remapped yet"),
        helpText("Please remap the data first using the panel on the left hand side")
      )
    }
  })


  ## We can only proceed if this is true
  succesfullyFinishedS2 <- reactive({
    if (!is.null(data2())) {
      TRUE
    } else {
      FALSE
    }
  })

  ## Do we have time
  hasTime <- reactive({
    if (is.null(data2()$dat)) {
      FALSE
    } else {
      if (!all(is.na(data2()$dat$timestamp))) {
        TRUE
      } else {
        FALSE
      }
    }
  })

  observe({
    if (!hasTime()) {
      createAlert(session, "generalNoTimeTTSI", "generalNoTimeTTSI1",
                  "Please provide date and time",
                  content ="This method requires date and time of relocations, but it was not provided", 
                  style="error", 
                  dismiss=FALSE,
                  append=FALSE)

      createAlert(session, "generalNoTimeBBMM", "generalNoTimeBBMM1",
                  "Please provide date and time",
                  content = "This method requires date and time of relocations, but it was not provided", 
                  style="error", 
                  dismiss=FALSE,
                  append=FALSE)
    } else {
      closeAlert(session, "generalNoTimeTTSI1")
      closeAlert(session, "generalNoTimeBBMM1")
      
    }
  })


  ## ============================================================================== ##  
  ## Subset data

  output$subsetUI <- renderUI({
    if (succesfullyFinishedS2()) {
      bbx <- bbox(rgeos::gBuffer(rgeos::gEnvelope(data2()$dat),
                                 width = max(apply(bbox(data2()$dat), 1, diff)) * 0.01))
      uis <- list(
        sliderInput("subsetXSlider", "X-Range", bbx[1, 1], bbx[1, 2], value=bbx[1, ]), 
        sliderInput("subsetYSlider", "Y-Range", bbx[2, 1], bbx[2, 2], value=bbx[2, ])
      )

      if (!all(is.na(data2()$dat$timestamp))) {
        uis <- c(uis, list(dateRangeInput("subsetDatePicker", "Date range:",
                                          start = format(min(data2()$dat$timestamp), "%Y-%m-%d"),
                                          end = format(max(data2()$dat$timestamp), "%Y-%m-%d"))))
      }

      ## select ids
      pcho <- unique(data2()$dat$id)
      if (debug) cat(pcho, "\n")

      uis <- c(uis, list(
        selectInput("subsetSelectedIds", "Select animals",
                    choices=pcho,
                    selected=pcho,
                    multiple=TRUE,
                    selectize=FALSE),
        hr() 
        ## actionButton("subsetReset", "Reset")
        ## helpText("Reset button to come here")
      ))
      return(uis)
    } else {
      return(NULL)
    }
  })

  ## Reactive slider values
  subsetXSliderValues <- reactive({
    input$subsetXSlider
  }) 

  subsetYSliderValues <- reactive({
    input$subsetYSlider
  }) 

  subsetDatePicker <- reactive({
    as.character(input$subsetDatePicker)
  })

  subsetSelectedIds <- reactive({
    input$subsetSelectedIds
  })

  ## data 3
  data3 <- reactive({
    if(!is.null(data2())) {
      if (debug) cat("starting to create data3----\n\n")

      if (length(subsetSelectedIds()) == 0L) {
        checked <- unique(data2()$dat$id)
      } else {
        checked <- subsetSelectedIds()
      }

      cat("[b] Recreating data3() with\n")
      cat(subsetSelectedIds(), "\n")
      cat(checked, "\n")
      cat("[e] ===========================\n")

      dat <- data2()$dat
      bbx <- if (!is.null(subsetXSliderValues()[1])) {
        rgeos::gEnvelope(rgeos::readWKT(
          paste0("MULTIPOINT((", subsetXSliderValues()[1], " ", subsetYSliderValues()[1], "), (",
                 subsetXSliderValues()[2], " ", subsetYSliderValues()[2], "))")))
      } else {
        rgeos::gEnvelope(dat)
      }

      cat("[f] ===========================\n")
      if (!all(is.na(data2()$dat$timestamp))) {
        b <- subsetDatePicker()
        if (debug) cat("## subset date picker \n\n")
        if (debug) cat(str(b))
        if (length(b) == 0) {
          b <- c("1900-1-1", "2050-1-1")
        }
        dat <- dat[dat$id %in% checked & 
                     dat$timestamp >= ymd(b[1]) &
                     dat$timestamp <= ymd(b[2]), ]
      } else {
        dat <- dat[dat$id %in% checked , ]
      }
      cat("[g] ===========================\n")

      dat <- dat[which(rgeos::gCovers(bbx, dat, byid=TRUE)), ]

      dataNew <- data2()
      dataNew$dat <- dat


      if (nrow(dat) == 0) {
        NULL
      } else {
        if (debug) cat(str(dataNew))
        if (debug) cat("exiting data3 without error----\n\n")
        dataNew
      }


    }
  })

  output$subsetPlot <- renderPlot({
    if (!is.null(data3())) {
      plot(rgeos::gBuffer(rgeos::gEnvelope(data2()$dat),
                          width = max(apply(bbox(data2()$dat), 1, diff)) * 0.01), border = NA)
      points(data2()$dat, col=adjustcolor("black", 0.1), pch=19)
      points(data3()$dat, col="red")
      axis(1)
      axis(2)
      abline(v=subsetXSliderValues(), col="blue", lty=2)
      abline(h=subsetYSliderValues(), col="blue", lty=2)
    } else {
      plot(0,0, type="n")
    }
  })

  ## Reset button: not yet implemented
  ## observe({
  ##   if (!is.null(data3())){
  ##     if (input$subsetReset == 0) {
  ##       cat("[e] ========over 1 \n")
  ##       return(NULL)
  ##     }
  ##     cat("[e] ========over 2 \n")
  ##       updateSliderInput(session, "subsetXSlider", "X-Range", value=range(data2()$lon))
  ##       updateSliderInput(session, "subsetYSlider", "Y-Range", value=range(data2()$lat))

  ##       if (FALSE){
  ##         if (!all(is.na(data2()$timestamp))) {
  ##           updateDateRangeInput(session, "subsetDatePicker", "Date range:",
  ##                                start = format(min(data2()$timestamp), "%Y-%m-%d"),
  ##                                end = format(max(data2()$timestamp), "%Y-%m-%d"))
  ##         }

  ##         ## select ids
  ##         pcho <- unique(data2()$id)

  ##         updateSelectInput(session, "subsetSelectedIds", "Select animals",
  ##                           choices=pcho,
  ##                           selected=pcho,
  ##                           multiple=TRUE,
  ##                           selectize=FALSE)
  ##       }
  ##   }
  ## })

  subsetTable <- reactive({
    if (!is.null(data3())) {
      dataa <- as.data.frame(table(data2()$dat$id))
      datbb <- as.data.frame(table(data3()$dat$id))
      dat <- merge(dataa, datbb, by="Var1", all.x=TRUE)
      dat$Freq.y <- ifelse(is.na(dat$Freq.y), 0, dat$Freq.y)

      names(dat) <- c("Id", "Total number of Points", "Currently selected")
      dat
    } else {
      dataa <- as.data.frame(table(data2()$dat$id))
      datbb <- as.data.frame(table(data4()$dat$id))
      dat <- merge(dataa, datbb, by="Var1", all.x=TRUE)
      dat$Freq.y <- ifelse(is.na(dat$Freq.y), 0, dat$Freq.y)

      names(dat) <- c("Id", "Total number of Points", "Currently selected")
      dat
    }
  })

  output$subsetTable <- renderDataTable({
    subsetTable()
  })


  ## ============================================================================== ##  
  ## Configure & Analysis

  data4 <- reactive({

    ## Just in case some skips the subset step
    if (!is.null(data3())) {
      data4 <- data3()
    } else {
      if (!is.null(data2())) {
        data4 <- data2()
      } else {
        data4 <- NULL
      }
    }
  })

  ## ------------------------------------------------------------------------------ ##  
  ## Input validation

  ## Site Fidelity
  observe({
    x <- as.numeric(input$configSiteFidelityN)
    if(is.na(x)) {
      updateNumericInput(session, "configSiteFidelityN", value=config$pointLevel$sf$n)
    }
  })

  ## TTSI
  observe({
    ttsiinit <- as.numeric(input$configTTSIInit)
    if(is.na(ttsiinit)) {
      updateNumericInput(session, "configTTSIInit", value=config$pointLevel$ttsi$interval)
    }

    ttsintimes <- as.numeric(input$configTTSINTimes)
    if(is.na(ttsintimes)) {
      updateNumericInput(session, "configTTSINTimes", value=config$pointLevel$ttsi$ntimes)
    }
  })


  ## Check for MCP
                                        # observe({
                                        #    input$btnModalMCPSave
                                        #
                                        #    isolate({
                                        #      x <- as.numeric(input$modalMCPInputLevel)
                                        #      
                                        #      ## This will change the value of input$inText, based on x
                                        #      if (!is.na(x) & x > 1 & x <= 100) {
                                        #        y <- x
                                        #      } else {
                                        #        y <- 95
                                        #      }
                                        #      updateTextInput(session, "modalMCPInputLevel", value = y)
                                        #    })
                                        #  })
                                        #
                                        #
                                        #

  ## ------------------------------------------------------------------------------ ##  
  ## Generate output grid

  output$configOuputGridBufferPlot <- renderPlot({
    if (!is.null(data4())) {
      bbx <- bbox(data4()$dat)
      xrange <- bufferXSliderValues() * c(-1, 1) + bbx[1, ]
      yrange <- bufferYSliderValues() * c(-1, 1) + bbx[2, ] 

      plot(data4()$dat, type="n", asp=1, ylim=yrange, xlim=xrange)
      abline(v=xrange, col="grey50", lty=1)
      abline(h=yrange, col="grey50", lty=1)
      polygon(c(xrange, rev(xrange)), rep(yrange, each=2), col=adjustcolor("red", 0.5), border="grey50")
      points(data4()$dat, col=adjustcolor("black", 0.1), pch=19)
    } else {
      plot(0,0, type="n")
    }
  })

  output$bufferUI <- renderUI({
    if (!is.null(data4())) {
      bbx <- bbox(data4()$dat)
      xrange <- diff(bbx[1, ]) 
      yrange <- diff(bbx[2, ]) 
      uis <- list(
        sliderInput("bufferXSlider", "X-Buffer", 0, xrange, xrange * 0.5), 
        sliderInput("bufferYSlider", "Y-Buffer", 0, yrange, yrange * 0.5)
      )
    } else {
      return(NULL)
    }
  })

  ## Reactive slider values
  bufferXSliderValues <- reactive({
    input$bufferXSlider
  }) 

  bufferYSliderValues <- reactive({
    input$bufferYSlider
  }) 

  ## ------------------------------------------------------------------------------ ##  
  ## Grid

  output$gridResUi <- renderUI({
    if (!is.null(data4())) {
     rgs <- apply(bbox(data4()$dat), 1, diff)
     rgs <- c(rgs / 10, rgs / 500)
     sliderInput("gridResSlider", "Resolution", 1, 1000, round(mean(rgs)))
    }
  })

  trast <- reactive({
    if (!is.null(data4())) {

      ext <- rhrExtFromPoints(data4()$dat,
                              buffer=c(bufferXSliderValues(), bufferYSliderValues()),
                              extendRange=NULL) 
      if (input$configOutputGridGrid == "pixel") {
        return(rhrRasterFromExt(ext, nrow=input$gridNColSlider, ncol=input$gridNRowSlider, res=NULL))
      } else {
        return(rhrRasterFromExt(ext, nrow=NULL, ncol=NULL, res=ceiling(input$gridResSlider)))
      }
    } else {
      return(NULL)
    }

  })

  output$printGrid <- renderPrint({
    cat(
      " Number of rows:   ", nrow(trast()), "\n",
      "Number of columns: ", ncol(trast()), "\n",
      "Resolution:        ", paste0(raster::res(trast()),  collapse=", "), "\n",
      "Number of cells:   ", raster::ncell(trast())
    )
  })

  ## -------------------------------------------------------------------------- ##
  ## levels

  observe({
    xx <- tryCatch(all(is.numeric(rhr:::rhrCheckLevels(
      strsplit(input$configGlobalLevel, ",")[[1]]))), 
                   error = function(e) return(FALSE))
    
    if (!xx) {
      updateTextInput(session, "configGlobalLevel", value = "95")
    }
  })


  ## ------------------------------------------------------------------------------ ##  
  ## locoh

  output$configLOCOHtypeKField <- renderUI({
    if (input$configLOCOHtypeK == "inclm") {
      list(
        numericInput("configLOCOHtypeKmanN", "Manual n", value=10)
        ## helpText("Several values are possible with '10,40,20', a range of values is possible with '10:40:10' to evaluate LoCoH at 10, 20, 30 and 40.")
      )
    } else {
      NULL
    }
  })
  
  output$configLOCOHtypeAField <- renderUI({
    if (input$configLOCOHtypeA == "inclm") {
      list(
        numericInput("configLOCOHtypeAmanN", "Manual n", value=10)
        ## helpText("Several values are possible with '10,40,20', a range of values is possible with '10:40:10' to evaluate LoCoH at 10, 20, 30 and 40.")
      )
    } else {
      NULL
    }
  })

  output$configLOCOHtypeRField <- renderUI({
    if (input$configLOCOHtypeR == "inclm") {
      list(
        numericInput("configLOCOHtypeRmanN", "Manual n", value=10)
        ## helpText("Several values are possible with '10,40,20', a range of values is possible with '10:40:10' to evaluate LoCoH at 10, 20, 30 and 40.")
      )
    } else {
      NULL
    }
  })

  ## ------------------------------------------------------------------------------ ##  
  ## KDE

  output$configKDEbandwidthUserInput <- renderUI({
    if ("user" %in% input$configKDEbandwidth) {
      list(
        numericInput("configKDEbandwithUser", "Bandwidth (manual)", value=100)
      )
    } else {
      NULL
    }
  }) 

  ## ============================================================================= ##
  ## Analzye

  ## Check we have date+time for the estimators that need it

  observe({
    if (!is.null(data4())) {
      updateButton(session, "rhrAnalyze", disable=FALSE)
      if (any(c("rhrTTSI", "rhrBBMM") %in% c(input$runSteps, input$runSteps2))) {
        if ("rhrTTSI" %in% c(input$runSteps, input$runSteps2) & !hasTime()) {
          createAlert(session, "rhrRunNoTimeTTSI", "rhrRunNoTimeTTSI1",
                      "Time to statistical independence",
                      content = "Date and time are required", 
                      style="error", 
                      dismiss=FALSE,
                      append=FALSE)
          updateButton(session, "rhrAnalyze", disable=TRUE)
        } else {
          closeAlert(session, "rhrRunNoTimeTTSI1")
        }
        if ("rhrBBMM" %in% c(input$runSteps, input$runSteps2) & !hasTime()) {
          createAlert(session, "rhrRunNoTimeBBMM", "rhrRunNoTimeBBMM1",
                      "Brownian Bridges Movement Model",
                      content = "Date and time are required", 
                      style="error", 
                      dismiss=FALSE,
                      append=FALSE)
          updateButton(session, "rhrAnalyze", disable=TRUE)
        } else {
          closeAlert(session, "rhrRunNoTimeBBMM1")
        }
      } else {
        closeAlert(session, "rhrRunNoTimeTTSI1")
        closeAlert(session, "rhrRunNoTimeBBMM1")
        updateButton(session, "rhrAnalyze", disable=FALSE)
      }
    }
  })

  observe({
    if (input$rhrAnalyze == 0) {
      return(NULL)
    }

    input$rhrAnalyze
    
    isolate({
      if (!is.null(data4())) {
        closeAlert(session, "rhrAnalyzeInfo1")

        runId <- paste0("rhr-run-", format(now(), "%Y%m%d%H%M%S"))
        outDir <- normalizePath(file.path(normalizePath(tempdir(), mustWork=FALSE, winslash="/"), runId), mustWork=FALSE, winslash="/")
        dir.create(outDir)
        addResourcePath("out", outDir)

        ## Create args
        args <- list(
          rhrSiteFidelity=list(
            n=input$configSiteFidelityN,
            alpha=input$configSiteFidelityAlpha), 
          rhrKDE=list(
            levels=rhrCorrectLevels(input$configGlobalLevel),
            trast=trast(), 
            h=input$configKDEbandwidth,
            userh=input$configKDEbandwithUser), 
          rhrBBMM=list(
            levels=rhrCorrectLevels(input$configGlobalLevel),
            trast=trast(), 
            sigma2=input$configBBMMSigma2, 
            rangesigma1=input$configBBMMRangeSigma1), 
          rhrMCP=list(
            levels=rhrCorrectLevels(input$configGlobalLevel)
          ), 
          rhrTTSI=list(
            init=input$configTTSIInit,
            consec=input$configTTSISampling,
            ntimes=input$configTTSINTimes,
            alpha=input$configTTSIAlpha
          ),
          rhrLoCoH=list(
            levels=rhrCorrectLevels(input$configGlobalLevel),
            n=do.call(base::c, list(
              switch(input$configLOCOHtypeK, "inclm" = input$configLOCOHtypeKmanN, "incla" = 10),
              switch(input$configLOCOHtypeA, "inclm" = input$configLOCOHtypeAmanN, "incla" = 10),
              switch(input$configLOCOHtypeR, "inclm" = input$configLOCOHtypeRmanN, "incla" = 10))), 
            autoN=do.call(base::c, list(
              switch(input$configLOCOHtypeK, "incla" = TRUE, "inclm" = FALSE),
              switch(input$configLOCOHtypeA, "incla" = TRUE, "inclm" = FALSE),
              switch(input$configLOCOHtypeR, "incla" = TRUE, "inclm" = FALSE))),
            type=do.call(base::c, list(
              switch(input$configLOCOHtypeK, "incla" = "k", "inclm" = "k", "not" = NULL),
              switch(input$configLOCOHtypeA, "incla" = "a", "inclm" = "a", "not" = NULL),
              switch(input$configLOCOHtypeR, "incla" = "r", "inclm" = "r", "not" = NULL)))
          ), 
          rhrAsymptote=list(
            minNP=input$configAsymptoteMinNP,
            si=input$configAsymptoteSI,
            nrep=input$configAsymptoteNRep,
            tolTotArea=input$configAsymptoteTolToA,
            nTimes=input$configAsymptoteNTimes,
            sampling=input$configAsymptoteSampling
          ),
          rhrUniNorm=list(
            levels=rhrCorrectLevels(input$configGlobalLevel),
            trast=trast()
          ),
          rhrBiNorm=list(
            levels=rhrCorrectLevels(input$configGlobalLevel),
            trast=trast()
          )
        )

        if (debug) cat("str anaylsis\n\n")
        if (debug) cat("=======================\n\n")
        if (debug) cat(str(args))
        if (debug) saveRDS(args, "/tmp/myrds.RDS")
        if (debug) cat("=======================\n\n")
        
        createAlert(session, "rhrAnalyzeProgress", "rhrAnalyzeProgress1",
                    "Starting Analysis",
                    content = paste0("[", Sys.time(), "] Preparing the analysis"), 
                    style="info", 
                    dismiss=FALSE,
                    append=FALSE)

        withProgress(message="starting analysis", {

          setProgress(message="Preparing calculations", detail="creating output files .....")

          files <- system.file("guiTemp", package="rhr")
          
          createAlert(session, "rhrAnalyzeProgress", "rhrAnalyzeProgress2",
                      "Starting Calculations",
                      content = paste0("[", Sys.time(), "] Starting with calculations, this may take some time"), 
                      style="info", 
                      dismiss=FALSE,
                      append=TRUE)

          ## ------------------------------------------------------------------------------ ##  
          ## Run the whole analysis
          if (debug) cat("===========\n", c(input$runSteps, input$runSteps2), "\n")
          starttime <- Sys.time()
          runtime <- system.time(res <- rhrHrAnalysis(data4(),
                                                      what=c(input$runSteps, input$runSteps2), 
                                                      args=args,
                                                      outDir=outDir,
                                                      inUnit=input$configOutputInUnits, 
                                                      outUnit=input$configOutputOutUnits, 
                                                      inGUI=TRUE, 
                                                      report = TRUE, 
                                                      createPDF = config()$general$content$doPdf), gcFirst=TRUE)
          if (debug) cat(str(res))
          ## ------------------------------------------------------------------------------ ##  
          ## Brew html

          createAlert(session, "rhrAnalyzeProgress", "rhrAnalyzeProgress3",
                      "Report",
                      content = paste0("[", Sys.time(), "] Generating report"), 
                      style="info", 
                      dismiss=FALSE,
                      append=TRUE)
            
          if (FALSE) {  ## this can most likely go after some testing
            brewEnv <- list2env(list(
              config=config(), 
              runtime=runtime,
              debug=TRUE, 
              res=res,
              baseDir=outDir,
              steps=input$selectStep, 
              dat=data4(),
              subsetTable=subsetTable(),
              methodLookup=methodLookup,
              epsgs=list(
                input=input$configInEpsg, 
                output=input$configOutEpsg),
              starttime = starttime
            ))
            
            knitEnv <- list2env(list(
              config=config(), 
              dat=data4(),
              data2=data2()$dat,
              data3=data3(),
              subsetTable=subsetTable(),
              relocTable=missingAndDuplicated()
            ))
            
            setProgress(message="Creating html file")
            if (debug) cat("files are: \n")
            if (debug) cat(files)
            if (debug) cat("\n\n")
            src <- capture.output(brew(file=normalizePath(file.path(files, "body.brew"), winslash="/", mustWork=FALSE), output=stdout(), envir=brewEnv))
            if (debug) cat(str(input$selectStep))
            
            
            foo <- knit(text=src, output=normalizePath(file.path(outDir, "rhrReport.Rmd"), mustWork=FALSE, winslash="/"), quiet=TRUE,
                        envir=knitEnv)
            
            setProgress(message="Just opening files", detail="new tab :) .....")
            markdownToHTML(
              output=normalizePath(file.path(outDir, "rhrReport.html"), mustWork=FALSE, winslash="/"), 
              file=normalizePath(file.path(outDir, "rhrReport.Rmd"), mustWork=FALSE, winslash="/"), 
              stylesheet=normalizePath(file.path(files, "style.css"), mustWork=FALSE, winslash="/"),
              template=normalizePath(file.path(files, "index.html"), mustWork=FALSE, winslash="/"))
            
            ### pdf
            if (config()$general$content$doPdf) {
              setProgress(message="Generating PDF", detail="may take a some time")
              brew(file=normalizePath(file.path(files, "report_brew.tex"), mustWork=FALSE, winslash="/"),
                   output=normalizePath(file.path(outDir, "rhrReport.Rnw"), mustWork=FALSE, winslash="/"),
                   envir=brewEnv)
              
              knit(input=normalizePath(file.path(outDir, "rhrReport.Rnw"), mustWork=FALSE, winslash="/"),
                   output=normalizePath(file.path(outDir, "rhrReport.tex"), mustWork=FALSE, winslash="/"), 
                   quiet=TRUE,
                   envir=knitEnv)
              
              ow <- setwd(outDir)
              createPDF <- tryCatch(tools::texi2pdf("rhrReport.tex", clean=TRUE), error=function(e) e)
              setwd(ow)
            }
            
            ## ------------------------------------------------------------------------------ ##  
            ## Clean up
            if (!debug) {
              file.remove(normalizePath(file.path(outDir, "rhrReport.Rnw"), mustWork=FALSE, winslash="/"))
              file.remove(normalizePath(file.path(outDir, "rhrReport.Rmd"), mustWork=FALSE, winslash="/"))
              file.remove(normalizePath(file.path(outDir, "rhrReport.tex"), mustWork=FALSE, winslash="/"))
            }
            unlink(normalizePath(file.path(outDir, "figure"), mustWork=FALSE, winslash="/"), recursive=TRUE)
            
          }

          ## ------------------------------------------------------------------------------ ##  
          ## Zip - Removed since it is not working on Windows
          ## createAlert(session, "rhrAnalyzeProgress", "rhrAnalyzeProgress4",
          ##             "Zip-file",
          ##             message=paste0("[", Sys.time(), "] Zipping all results"), 
          ##             style="info", 
          ##             dismiss=FALSE,
          ##             append=TRUE)

          ## if (config()$general$content$doZip) {
          ##   ow <- setwd(outDir)
          ##   zip(paste0(runId, ".zip"), files=list.files(full.names=TRUE, include.dirs=TRUE))
          ##   if (config()$general$content$doCp) {
          ##     file.copy(paste0(runId, ".zip"), config()$general$content$wd)
          ##   }
          ##   setwd(ow)
          ## }

           if (config()$general$content$doCp) {
             dir.create(normalizePath(file.path(config()$general$content$wd, runId), mustWork=FALSE, winslash="/"))
             filesNames <- list.files(outDir, full.names=TRUE, recursive=FALSE, ignore.case=TRUE)
             sapply(filesNames, function(x)
                    file.copy(from=x, to=normalizePath(file.path(config()$general$content$wd, runId), mustWork=FALSE, winslash="/")))

             for (f in c("data", "plots", "vector", "raster")) {
               dir.create(normalizePath(file.path(config()$general$content$wd, runId, f), mustWork=FALSE, winslash="/"))
               filesNames <- list.files(normalizePath(file.path(outDir, "results", f), mustWork=FALSE, winslash="/"), full.names=TRUE, recursive=TRUE,
                                        ignore.case=TRUE)
               sapply(filesNames, function(x)
                      file.copy(from=x, to=normalizePath(file.path(config()$general$content$wd, runId, f), mustWork=FALSE, winslash="/")))
             }
             
           }

          createAlert(session, "rhrAnalyzeProgress", "rhrAnalyzeProgress5",
                      "Finish",
                      content =paste0("[", Sys.time(), "] Finished analysis"), 
                      style="info", 
                      dismiss=FALSE,
                      append=TRUE)
          
        })
        browseURL(normalizePath(file.path(outDir, "rhrReport.html"), mustWork=FALSE, winslash="/"))
      } else {
        createAlert(session, "rhrAnalyzeInfo", "rhrAnalyzeInfo1",
                    "Not ready yet",
                    content ="Please load and remap the data before you try to run an analysis", 
                    style="error", 
                    dismiss=TRUE,
                    append=FALSE)
      }
    })
  })

})
