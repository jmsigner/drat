library(testthat)
library(rhr)

test_check("rhr")
