#' Fit a distribution to step lenghts
#'
#' Fit a suitable statistical distribution to step lengths of regularly sampled animal track(s). Currently only a Gamma distribution is implemented.
#'
#' @param x Object of class \code{RhrTrack(s)STR}
#' @param ... Further arguments passed to `fitdistrplus::fitdist`
#' @export
#' 
rhrFitStepLengthDist <- function(x, ...) {
  UseMethod("rhrFitStepLengthDist")
}

#' @export
rhrFitStepLengthDist.RhrTrackSTR <- function(x, ...) {
  rhr:::rhrFitStepLengthDist_base(
    rhr::rhrSegments(x, spatial = FALSE)$dist, ...)
}

#' @export
rhrFitStepLengthDist.RhrTracksSTR <- function(x, ...) {
  rhr:::rhrFitStepLengthDist_base(
    do.call(base::c, 
            lapply(x, function(y) rhr::rhrSegments(y, spatial = FALSE)$dist)), ...)
  
  
}

rhrFitStepLengthDist_base <- function(x, start = list(scale = 1, shape = 1), ...) {
  if (any(x == 0)) {
    stop("0 length steps are not possible, consider adding a random error")
  }
  
  m <- fitdistrplus::fitdist(x, "gamma", method = "mle", 
                             lower = c(0, 0), 
                             start = start, ...)
  m
}


# Fit turning angle distribution ------------------------------------------

#' Fit a distribution to turning angles
#'
#' Fit a suitable statistical distribution to step lengths of regularly sampled animal track(s). Currently only a Gamma distribution is implemented.
#'
#' @param x Object of class \code{RhrTrack(s)STR}
#' @param ... Further arguments passed to `fitdistrplus::fitdist`
#' @export
#' 
rhrFitTurnAngleDist <- function(x, ...) {
  UseMethod("rhrFitTurnAngleDist")
}

#' @export
rhrFitTurnAngleDist.RhrTrackSTR <- function(x, ...) {
  rhr:::rhrFitTurnAngleDist_base(
    rhr::rhrSegments(x, spatial = FALSE)$direction)
}

#' @export
rhrFitTurnAngleDist.RhrTracksSTR <- function(x, ...) {
  rhr:::rhrFitTurnAngleDist_base(
    do.call(base::c, 
            lapply(x, function(y) rhr::rhrSegments(y, spatial = FALSE)$direction)))
}

rhrFitTurnAngleDist_base <- function(x, ...) {
  circular::mle.vonmises(x, ...)
}


# Generate Case Controll steps --------------------------------------------

#' Generate Case and Control points of a track
#'
#' Generates control steps for each step of a movement track, often used for analyzing habitat selection with step selection functions (SSF).
#'
#' The first step of each path (possibly subpath) is omitted because of the lack of relative turning angles.
#'
#' @param x Object of class \code{RhrTrack*}
#' @param n_controll The number of control steps.
#' @param add_time Logical value indicating if time stamp of each step should be added.
#' @template dots
#' @export
#' 
rhrCaseControl <- function(x, ...) {
 UseMethod("rhrCaseControl")
}

#' @export
rhrCaseControl.RhrTracksSTR <- rhrCaseControl.RhrTrackSTR <- function(x, sl, ta, n_controll = 10, add_time = TRUE, ...) {
  
  x <- rhrSegments(x)
  x <- x[complete.cases(x), ]
  
  if (!is(sl, "fitdist")) {
    stop("Step length should be of type fdist")
  }
  
  ## Generate random points
  ns <- nrow(x)  # number of steps
  case_for_controll <- rep(1:ns, each = n_controll)
  l <- c(list(n = ns * n_controll), as.list(sl$estimate))
  sl <- do.call(paste0("r", sl$distname), l)
  
  ta <- x[case_for_controll, "direction"] + 
    circular::rvonmises(ns * n_controll, mu = 0, kappa = ta$kappa)  # turning angles for new stps
  
  ## Controll points
  xy_cc <- x[case_for_controll, ]
  xy_cc[, "x1"] <- xy_cc[, "x0"] + sl * cos(ta)
  xy_cc[, "y1"] <- xy_cc[, "y0"] + sl * sin(ta)
  
  cc_df <- do.call(rbind, list(
    data.frame(
      step_id = 1:ns, 
      case = TRUE,
      xstart = x[, "x0"], 
      ystart = x[, "y0"], 
      xend = x[, "x1"], 
      yend = x[, "y1"], 
      distance = x$distance
    ), 
    data.frame(
      step_id = rep(1:ns, each = n_controll), 
      case = FALSE,
      xstart = x[case_for_controll, "x0"], 
      ystart = x[case_for_controll, "y0"], 
      xend = xy_cc[, "x1"], 
      yend = xy_cc[, "y1"], 
      distance = sl
    )
  ))
  
  if (add_time) {
    cc_df$start <- c(x[, "start"], x[case_for_controll, "start"]) 
    cc_df$end <-  c(x[, "end"], x[case_for_controll, "end"])
  }
  cc_df
}
  
