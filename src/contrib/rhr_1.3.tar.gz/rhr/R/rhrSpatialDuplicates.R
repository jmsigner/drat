#' Handle spatial duplicates
#' 
#' Functions to detect and remove spatial duplicates in a track.
#' 
#' @param x Object of class \code{RhrTrack*}
#' @param by_point Logical scalar, indicating whether or not each point should be treated individually. 
#' @template dots
#' @export
#' @examples 
#'
#' a <- SpatialPoints(cbind(c(1, 1:9, 2, 2:5), c(1, 1:9, 2, 2:5)))
#' 
#' # For a single track
#' tr <- rhrTrack(a)
#' dp <- rhrSpatialDuplicated(tr)
#' tr[!dp, ]
#' 
#' 
#' # For multiple tracks
#' tr <- rhrTracks(a, id = rep(1:2, c(10, 5)))
#' dp <- rhrSpatialDuplicated.RhrTracksS(tr, by_point = TRUE)
#' class(tr)
#' 
#' for (i in seq_along(length(tr)))
#'   tr[[i]] <- tr[[i]][!dp[[i]], ]

#' 
rhrSpatialDuplicated <- function(x, ...) {
 UseMethod("rhrSpatialDuplicated")
}

#' @export
rhrSpatialDuplicated.RhrTrackS <- function(x, ...) {
  
  pts <- rhrPoints(x)
  duplicated(coordinates(pts))
}
  
#' @export
rhrSpatialDuplicated.RhrTracksS <- function(x, by_point = FALSE, ...) {
  lapply(x, function(x) rhrSpatialDuplicated(x, by_point, ...))
}
